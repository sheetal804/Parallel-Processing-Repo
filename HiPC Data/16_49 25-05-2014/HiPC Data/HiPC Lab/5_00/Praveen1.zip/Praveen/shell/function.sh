SayHello()
{
	echo "hello $LOGNAME, How are you?"
	return
}
SayHello
