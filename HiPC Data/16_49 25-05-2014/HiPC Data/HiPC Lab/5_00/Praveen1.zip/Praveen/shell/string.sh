clear
echo "Enter a strings :"
read string1
if [ $string1 = 'y' -o $string1 = 'Y' ]
then
	echo "YES"	
else
	echo "NO"
fi

