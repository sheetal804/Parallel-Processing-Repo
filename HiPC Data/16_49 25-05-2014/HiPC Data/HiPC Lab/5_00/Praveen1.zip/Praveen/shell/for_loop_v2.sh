for (( i = 1 ; i <= 50 ; i++ ))
do 
	echo "$i"
done
