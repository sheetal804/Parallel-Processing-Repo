#include<stdio.h>
int main(){
	int a,b,sum;
	scanf("%d %d",&a,&b);
	sum=add(a,b);
	printf("Sum :%d\n",sum);
	return 0;
}
