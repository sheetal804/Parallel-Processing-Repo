#include<stdio.h>
#include<math.h>
/*int compute_ti(int a,int n)
{
	int fact=t=1,sum=0;
	for(i=1;i<=n;i++)
	{
		fact=fact*i;
		t=t*a;
		ti=fact/t;
		sum=sum+ti;
	}
	
}*/
int fact(int n)
{
	int i,fact=1;
	for(i=1;i<=n;i++)
	{ 
		fact=fact*i;
	}
return fact;
}
float pow_x(float a,int n)
{
	int temp_x=1,i;
	for(i=1;i<=n;i++)
	{
		temp_x=temp_x*a;
	}
return temp_x;
}
int main()
{
	float a,k,sum=0;
	int i,n;
	scanf("%f",&a);
	scanf("%d",&n);
	k=exp(a);
	for(i=0;i<=n;i++)
	{
		sum=sum+(float)(pow_x(a,i)/fact(i));
	}
	printf("Using Lib func:%f",k);
	printf("\nUsing general method:%f",sum);


}
