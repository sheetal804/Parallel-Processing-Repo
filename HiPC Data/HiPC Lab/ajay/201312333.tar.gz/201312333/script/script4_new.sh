read a b c d e
for (( i=1; i<=5; i++))
	
