temph=`date | cut -c12-13`
if [ $temph -lt 12 ]
then 
echo "gd mrng"
else
echo "qhuh"
fi
