#include<stdio.h>
int main()
{
	int a=5,b=10;
	printf("%d",add(a,b));
	return 0;
}
