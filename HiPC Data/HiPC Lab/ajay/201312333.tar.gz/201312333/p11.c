#include<stdio.h>
int fact(int a)
{
	int fact=1,i=1;
	for(i=1;i<=a;i++)
	{
		fact=fact*i;
	}
	return fact;
}
int fact_rec(int a)
{
	if(a==0)
		return 1;
	else
		return a*fact_rec(a-1);
}
int main()
{
	int a;
	scanf("%d",&a);
	printf("the factorial:%d",fact(a));
	printf("the rec factorial:%d",fact_rec(a));


}
