s=` expr $1 + $2`
echo "answer="
echo $s
