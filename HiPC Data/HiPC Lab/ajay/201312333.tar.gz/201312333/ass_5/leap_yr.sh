echo "Enter the yr"
read yr
a=`expr $yr % 100`
b=`expr $yr % 4`
c=`expr $yr % 400`
if [ $b -eq 0 -a  $a -ne 0 -o $c -eq 0 ]
then 
echo "yr is leap yr"
else
echo "yr is nt a leap yr"
fi
	
