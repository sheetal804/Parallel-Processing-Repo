
clear
echo "hello $USER"
echo "Today is \c";date
echo "number of user login :\c" ;who|wc -l

echo "ajay kumar khetan"
echo ajay kumar khetan
echo ajay;
echo 'ajay'

echo "calender"
cal
exit()
