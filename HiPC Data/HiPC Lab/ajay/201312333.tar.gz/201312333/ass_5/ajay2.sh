echo "enter a"
read a
echo "enter b"
read b
echo ` expr $a \* $b`
#echo "hello $c"
