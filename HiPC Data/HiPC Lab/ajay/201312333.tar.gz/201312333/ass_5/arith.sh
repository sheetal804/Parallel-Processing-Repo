expr 1 + 3
echo expr 6 + 3
