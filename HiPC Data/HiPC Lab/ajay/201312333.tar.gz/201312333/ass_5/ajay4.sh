echo $#
echo $*
