for i in 1 2 3 4 5
#for ((i=1;i<=5;i=i+1))
do
echo "welcome $i times"
done
