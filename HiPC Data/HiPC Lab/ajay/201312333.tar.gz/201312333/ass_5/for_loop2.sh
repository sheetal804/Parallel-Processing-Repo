for(( i=1; i <= 5; i++ ))
do
	for(( j=1; j <= 5; j++ ))
	do
	echo  -n "$i"
	done
echo	"####print the new line"
done
