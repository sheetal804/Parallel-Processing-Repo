echo "enter a"
read a
case $a in
1|2|3)echo " inside case 1";;

3)echo "inside case 3";;
esac

